
rootProject.name = "LojaDeVarejoExercicio"

