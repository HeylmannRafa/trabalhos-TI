class Fornecedor {
    var empresa: String? = ""
    var localizacao: String? = null
    var referencia: String? = ""
    var capacidadeDeFornecimento: String? = null
    var prazo: String? = ""
    var custoDoFrete: Short? = null
    var formasDePagamento: String? = null
}