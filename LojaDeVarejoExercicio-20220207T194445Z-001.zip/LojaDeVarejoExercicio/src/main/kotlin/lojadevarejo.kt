class vendedor{
    var nome:String? = ""
    var idade: Byte? = null
    var documentos: String? = ""
    var endereco: String? = ""
    var experiencia: String? = null
    var educacao: String? = ""
    var antecedentes: String? = null
    var telefone: Short? = null
    var cliente: Cliente? = null
    var fornecedor: Fornecedor? = null
    var produto: Produto? = null
    var venda: Venda? = null
    var transportadora: Transportadora? = null
}