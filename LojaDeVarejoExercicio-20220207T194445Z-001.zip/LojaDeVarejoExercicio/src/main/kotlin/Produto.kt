class Produto {
    var procedencia: String? = ""
    var qualidade: String? = null
    var marca: String? = null
    var beneficio: String? = ""
    var preco: Short? = null
    var pagamento:String? = ""
}