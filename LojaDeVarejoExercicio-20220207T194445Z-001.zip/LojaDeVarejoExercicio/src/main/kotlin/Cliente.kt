class Cliente {
    var nome: String? = ""
    var documentos: String? = null
    var endereco: String? = ""
    var telefone: Short? = null
    var credito: Short? = null
}