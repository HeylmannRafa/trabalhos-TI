class Venda {
    var plataformasDeVenda: String? = ""
    var estoque: String? = null
    var divulgacao: String? = null
}