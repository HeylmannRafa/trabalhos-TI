class Transportadora {
    var sustentabilidade:String? = null
    var rastreio:String? = null
    var seguraca: String? = null
    var protecaoPerdas: String? = null
}